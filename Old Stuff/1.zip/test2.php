<?php

//Step1
 $db = mysqli_connect('localhost','root','','coffeedb')
 or die('Error connecting to MySQL server.');
 
 
  //fetch table rows from mysql db
    $sql = "SELECT * FROM shopdetails";
    $result = mysqli_query($db, $sql) or die("Error in Selecting " . mysqli_error($db));

    //creates an array which will hold th e information on all the coffee shops
    $emparray = array();

	//Adds every row of the database table to the emparray that was created
    while($row =mysqli_fetch_assoc($result))
    {
        $emparray[] = $row;
    }
	
	//creates a json file called coffeedata, assigns it to $fp
    $fp = fopen('coffeeData.json', 'w');
	//writes the array from empyarray to the coffeedata.json file
    fwrite($fp, json_encode($emparray));
	//closes the file, stops any more changes from being made
    fclose($fp);
    echo json_encode($fp);

    //close the db connection, always good practice to do this
    mysqli_close($db);
?>